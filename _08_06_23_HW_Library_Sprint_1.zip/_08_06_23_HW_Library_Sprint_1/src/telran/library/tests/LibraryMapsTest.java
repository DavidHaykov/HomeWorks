package telran.library.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;

class LibraryMapsTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }
    @AfterAll
    static void afterAll() throws Exception{
    }
    @BeforeAll
    static void beforeAll() throws Exception{
    }

    @Test
    void test() {

    }


}