package telran.net;

public enum TcpResponseCode
{
	OK, WRONG_REQUEST, UNKNOWN
}
