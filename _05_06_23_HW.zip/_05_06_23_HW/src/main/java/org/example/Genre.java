package org.example;

public enum Genre {
    FANTASY, NOVEL, DETECTIVE, HISTORY;
}
