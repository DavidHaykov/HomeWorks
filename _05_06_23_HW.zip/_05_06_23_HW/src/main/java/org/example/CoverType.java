package org.example;

public enum CoverType {
    SOLID, SOFT;
}
