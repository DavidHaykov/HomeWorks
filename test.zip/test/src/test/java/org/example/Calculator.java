package org.example;

public class Calculator {
    public static int sum(int x, int y){
        return x+y;
    }
    public static int dic(int x, int y){
        return x/y;
    }
    public static int mul(int x, int y){
        return x*y;
    }
    public static int sub(int x, int y){
        return x-y;
    }
    public static boolean isEven(int x){
        return x%2==0;
    }
}
