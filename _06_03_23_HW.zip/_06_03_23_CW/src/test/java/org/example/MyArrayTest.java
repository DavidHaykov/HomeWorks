package org.example;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class MyArrayTest {
    IArray numbers;
    IArray strings;
    Integer[] arNumbers = {10,7,11,-2,13,10,2000};
    String[] arStrings = {"abc", "lmn", "qwerty", "abc"};


    @BeforeEach
    void setUp() throws Exception{
        numbers = new MyArray();
        for(int i = 0; i<arNumbers.length; i++){
            numbers.add(arNumbers[i]);
        }
        strings = new MyArray(1);
        for(int i = 0; i<arStrings.length; i++){
            strings.add(arStrings[i]);
        }
    }


    @Test
    void testAddGetSize() {
        int sizeNumbers = numbers.size();
        int sizeStrings = strings.size();
        assertEquals(arNumbers.length, sizeNumbers);
        assertEquals(arStrings.length, sizeStrings);
        for(int i = 0; i< sizeNumbers; i++){
            assertEquals(numbers.get(i), arNumbers[i]);
        }
        for(int i = 0; i< sizeStrings; i++){
            assertEquals(strings.get(i), arStrings[i]);
        }

    }


    @Test
    void indexOf() {
        assertEquals(0,numbers.indexOf(10));
        assertEquals(6,numbers.indexOf(2000));
        assertEquals(-1,numbers.indexOf(100));
        assertEquals(0,strings.indexOf("abc"));
        assertEquals(-1,strings.indexOf("abcd"));
    }

    @Test
    void lastIndexOf() {
        assertEquals(5,numbers.lastIndexOf(10));
        assertEquals(6,numbers.lastIndexOf(2000));
        assertEquals(-1,numbers.lastIndexOf(100));
        assertEquals(3,strings.lastIndexOf("abc"));
        assertEquals(-1,strings.lastIndexOf("abcd"));

    }

    @Test
    void testRemoveAtIndex(){
        Integer[] actual = {10,7,-2,13,10,2000}; //remove index 2
        Integer[] expected = {10,-2,13,10,2000};
        assertNull(numbers.remove(100));
        assertEquals(11,numbers.remove(2));

        assertEquals(numbers.size(), actual.length);
        for(int i = 0; i< actual.length; i++){
            assertEquals(numbers.get(i), actual[i]);
        }

    }

    @Test
    void testRemoveObject() {
        Integer[] actual = {10,7,-2,13,10,2000};  //remove object 11;
        assertTrue(numbers.remove((Integer)11));
        assertEquals(numbers.size(), actual.length);
        for(int i = 0; i< actual.length; i++){
            assertEquals(numbers.get(i), actual[i]);
        }
    }

    @Test
    void contains() {
        assertTrue(numbers.contains(10));
        assertTrue(numbers.contains(13));
        assertTrue(numbers.contains(-2));
        assertFalse(numbers.contains(111));
        assertFalse(numbers.contains(20001));
    }
    @Test
    void addIndex(){
        assertTrue(numbers.add(1,2));


    }

    @Test
    void toArray() {
        Integer[] expected = {10,7,11,-2,13,10,2000};
        String[] expected1 = {"abc", "lmn", "qwerty", "abc"};

        assertArrayEquals(expected, numbers.toArray());
        assertArrayEquals(expected1, strings.toArray());

    }
}