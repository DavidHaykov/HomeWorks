package org.example;

import java.util.Arrays;

public class MyArray implements IArray{

    private static final int DEFAULT_CAPACITY = 16;

    private Object[] array;
    private int size = 0;

    public MyArray(int capacity){
        array = new Object[capacity];
    };

    public MyArray(){
        array = new Object[DEFAULT_CAPACITY];
    }
    @Override
    public boolean add(Object obj) {
        if(obj ==null){
            return false;
        }
        if(size == array.length){
            allocateArray();


        }
        array[size]= obj;
        size++;
        return true;
    }
    private void allocateArray(){
        array = Arrays.copyOf(array, array.length + DEFAULT_CAPACITY);
    }


    @Override
    public boolean add(int index, Object obj) {
        if(index<0||index>size||obj==null)
            return false;
        if(size == array.length)
            allocateArray();
        Object[] res = Arrays.copyOf(array,size+1);

        for(int i = 0; i<size;i++){
            if(i >= index){
                array[i+1] = res[i];
            }
        }
        array[index] = obj;
        return true;
    }

    @Override
    public Object get(int index) {
        if(index<0||index>=size)
            return null;
        return array[index];
    }



    @Override
    public int size() {
        return size;
    }

    @Override
    public int indexOf(Object obj) {
        for(int i = 0; i< size; i++){
            if(array[i].equals(obj))
                return i;
        }
        return -1;
    }

    @Override
    public int lastIndexOf(Object obj) {
        for(int i = size-1; i > 0; i--){
            if(array[i].equals(obj))
                return i;
        }
        return -1;
    }

    @Override
    public Object remove(int index) {
        if(index < 0|| index >= size ){
            return null;
        }
        Object res = array[index];
        if(index < size-1)
            System.arraycopy(array, index+1, array, index, size-index-1);
        size--;
        return res;
    }

    @Override
    public boolean remove(Object obj) {
        if(obj==null)
            return false;
        return remove(indexOf(obj))!=null;
    }

    @Override
    public boolean contains(Object obj) {
        if(indexOf(obj)==-1)
            return false;

        return true;
    }

    @Override
    public Object[] toArray() {
        return Arrays.copyOf(array, size);
    }
}
