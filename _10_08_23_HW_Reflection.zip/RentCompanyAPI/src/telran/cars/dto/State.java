package telran.cars.dto;

public enum State {
    BAD, GOOD, EXCELLENT
}
