package numbers.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import telran.numbers.*;

public class NumbersBoxTest
{
	int allNumbers[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	int noDividedBy3[] = { 1, 2, 4, 5, 7, 8, 10 };
	int noInRange8_11[] = { 1, 2, 3, 4, 5, 6, 7 };

	INumbersBox numbersBox;

	@Before
	public void setUp() throws Exception
	{
//		numbersBox=new NumbersBoxArrayList();
//		numbersBox=new NumbersBoxLinkedList();
		numbersBox=new NumbersBoxHashSet();
//		numbersBox = new NumbersBoxTreeSet();
		for (int number : allNumbers)
		{
			numbersBox.addNumber(number);
		}
	}

	@Test
	public void addContainsSizeTest()
	{
		runTest(allNumbers);
	}

	@Test
	public void removeDividedByTest()
	{
		numbersBox.removeDividedBy(3);
		runTest(noDividedBy3);
	}

	@Test
	public void removeInRangeTest()
	{
		numbersBox.removeInRange(8, 11);
		runTest(noInRange8_11);
	}

	@Test
	public void removeRepeatedTest()
	{
		runTest(allNumbers);
		numbersBox.addNumber(1);
		numbersBox.addNumber(5);
		numbersBox.addNumber(10);
		numbersBox.removeRepeated();
		runTest(allNumbers);
	}

	private void runTest(int[] array)
	{
		assertEquals(array.length, numbersBox.size());
		for (int number : array)
			assertTrue(numbersBox.containsNumber(number));

	}

}
