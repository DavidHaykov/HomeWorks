package telran.numbers;

import java.util.HashSet;

public class NumbersBoxHashSet extends AbstractNumbersBoxSet
{
	public NumbersBoxHashSet()
	{
		collection = new HashSet<>();
	}
}
