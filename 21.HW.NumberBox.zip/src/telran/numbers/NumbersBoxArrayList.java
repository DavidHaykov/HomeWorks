package telran.numbers;

import java.util.*;

public class NumbersBoxArrayList extends AbstractNumbersBoxList
{
	public NumbersBoxArrayList()
	{
		collection = new ArrayList<>();
	}
}
