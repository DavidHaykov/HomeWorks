package telran.numbers;

import java.util.*;

public class NumbersBoxLinkedList extends AbstractNumbersBoxList
{
	public NumbersBoxLinkedList()
	{
		collection = new LinkedList<>();
	}
}
