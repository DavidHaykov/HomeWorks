package telran.numbers;

import java.util.HashSet;
import java.util.function.Predicate;

public abstract class AbstractNumbersBoxList extends AbstractNumbersBoxCollection
{

	@Override
	public void removeRepeated()
	{
		HashSet<Integer> helper = new HashSet<>();//1 2
		collection.removeIf(new Predicate<Integer>()//1 2
		{
			@Override
			public boolean test(Integer t)
			{
				return !helper.add(t);
			}
		});
	}
}
