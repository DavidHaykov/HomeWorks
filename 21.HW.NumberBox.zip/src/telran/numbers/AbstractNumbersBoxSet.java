package telran.numbers;

public abstract class AbstractNumbersBoxSet extends AbstractNumbersBoxCollection
{
	@Override
	public void removeRepeated()
	{
	}
}
