public class MessageBox {
    private String message;

    public synchronized void put(String message){
        while(this.message != null){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace(System.out);
            }
        }
        this.message = message;
        this.notifyAll();
    }
    public synchronized String take(){
        if(this.message == null){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace(System.out);
            }
        }
        String res = this.message;
        this.message = null;
        this.notifyAll();
        return res;
    }

}
