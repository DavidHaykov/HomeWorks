public class Consumer extends Thread{
    MessageBox box;
    public volatile boolean running = true;

    public Consumer(MessageBox box) {
        this.box = box;
    }
    public void run(){
        while (running){
            String message = box.take();
            System.out.printf("Thread: %s, id: %d message: %s\n", getName(), getId(), message);
        }
    }
}