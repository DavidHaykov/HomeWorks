package telran.cars.utils;

public interface Persistable
{
	void save(String fileName);
}
