package telran.cars.dto;

public enum CarsReturnCode
{
	OK, MODEL_EXISTS, CAR_EXISTS, DRIVER_EXISTS, NO_MODEL, NO_DRIVER, NO_CAR
}
