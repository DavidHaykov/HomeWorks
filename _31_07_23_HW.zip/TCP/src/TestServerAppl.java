import telran.net.server.ServerJava;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class TestServerAppl {
    public static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        ServerJava server = new ServerJava(new ProtocolTest(), 2000);
        Thread serverThread = new Thread(server);
        serverThread.start();
        System.out.println("To stop server enter STOP");
        while(true){
            String in = scanner.nextLine();
            if(in.equalsIgnoreCase("stop")){
                break;
            }
        }
        server.stopServer();

    }

}
