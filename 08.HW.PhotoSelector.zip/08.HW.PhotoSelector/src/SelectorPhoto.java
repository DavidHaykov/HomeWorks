public class SelectorPhoto
{

	public static String[] selectPictures(String[] pictures, String regEx)
	{
		return null;
	}

}
