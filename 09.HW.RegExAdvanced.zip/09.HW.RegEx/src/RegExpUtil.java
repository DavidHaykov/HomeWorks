
public class RegExpUtil
{

	public static String[] regexPatternMatchStream(String regexp, String string)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
