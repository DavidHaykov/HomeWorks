package variables;

public class Variables {

	int y;
	
	public static void main(String[] args) {
		
		byte x;
		x = (byte) 200;
		System.out.println(x);
		
		char c = 'N';
		System.out.println(c);
		
		var z = 1000l;
		var a = 1.1f;
		
		int res = x;
		
		short res1 = (short) res;
	}

}
