package teltan.cars.dto;

public enum CarsReturnCode {
    OK, MODEL_EXISTS, CAR_EXISTS, DRIVER_EXISTS, NO_MODEL, NO_DRIVER, CAR_REMOVED, CAR_IN_USE, NO_CAR
}
