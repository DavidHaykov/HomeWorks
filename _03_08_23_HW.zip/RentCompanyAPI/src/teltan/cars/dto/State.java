package teltan.cars.dto;

public enum State {
    BAD, GOOD, EXCELLENT
}
