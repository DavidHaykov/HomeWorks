
public class Anagram
{
//	Use the merge() method and lambda expression when working with the map instead of getOrDefault() and put() methods
	public static boolean isAnagram(String word, String string)
	{
		// TODO Auto-generated method stub
		return false;
	}

}
