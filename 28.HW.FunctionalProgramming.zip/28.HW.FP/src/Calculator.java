
public class Calculator
{
//	Write a map based calculator application, where you will have an operator as a key, and a functional interface as a 
//	value, where you will pass the corresponding arithmetic operation. Take the Calculator from the lesson 8 as a basis.
//
//	static Map<String,BinaryOperator<Integer>> mapOperations;
//		static {
//			mapOperations=new HashMap<>();
//			mapOperations.put("+", ...);
//			mapOperations.put("*", ...);
//			mapOperations.put("-", ...);
//			mapOperations.put("/", ...);
//		}

	public static Integer computeExpression(String string)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
