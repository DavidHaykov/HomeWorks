package org.example;

public interface IPrintable {
    void print();



}
